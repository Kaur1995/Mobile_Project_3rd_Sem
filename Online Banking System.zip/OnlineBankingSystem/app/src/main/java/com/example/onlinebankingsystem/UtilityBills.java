package com.example.onlinebankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;

import java.util.ArrayList;

public class UtilityBills extends AppCompatActivity {
    EditText subscriptionID;
    EditText amount;
    ListView listOfAccounts;
    ListView listOfUtilityBills;
    Button PButton;
    String cardNo;
    String utilBValue;
    AccountHolders accountHolders;
    String accountNo;
    ArrayAdapter adapterOfAccount, adapterOfutilityBills;
    double from;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_utility_bills);

        subscriptionID = (EditText) findViewById(R.id.subscriptionID);
        amount = (EditText) findViewById(R.id.amount);
        listOfAccounts = (ListView) findViewById(R.id.listOfAccounts);
        listOfUtilityBills = (ListView) findViewById(R.id.listOfUtilityBills);
        PButton = (Button) findViewById(R.id.PButton);
        Intent incomingIntent = getIntent();
        cardNo = incomingIntent.getStringExtra("AcessCardID");
        final ArrayList<String> listoAcc = new ArrayList<>();
        final ArrayList<String> listoUb = new ArrayList<>();


        listoUb.add("Utilitiy_Bill_Gas");
        listoUb.add("Utilitiy_Bill_Phone");
        listoUb.add("Utilitiy_Bill_Hydro");
        listoUb.add("Utilitiy_Bill_Water");

        adapterOfutilityBills = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoUb);
        listOfUtilityBills.setAdapter(adapterOfutilityBills);
        listOfUtilityBills.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                for( int j =0;j<listOfUtilityBills.getChildCount();j++){
                    listOfUtilityBills.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                }
                listOfUtilityBills.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                utilBValue = listoUb.get(i);
                System.out.println(utilBValue);
            }
        });


        if(Dashboard.dc.getA1().getAccessCardNumber().equals(cardNo)){
            for(Accounts a:Dashboard.dc.getA1().getListOfAccounts()){
                listoAcc.add("Account No: "+a.getAccountID());
            }
            adapterOfAccount = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
            listOfAccounts.setAdapter(adapterOfAccount);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));

                    accountHolders = Dashboard.dc.getA1();
                    accountNo = Dashboard.dc.getA1().getListOfAccounts().get(i).getAccountID();
                }
            });
        }else if (Dashboard.dc.getA2().getAccessCardNumber().equals(cardNo)){
            for(Accounts a:Dashboard.dc.getA2().getListOfAccounts()){
                listoAcc.add("Account No: "+a.getAccountID());
            }
            adapterOfAccount = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
            listOfAccounts.setAdapter(adapterOfAccount);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                    accountHolders = Dashboard.dc.getA2();
                    accountNo = Dashboard.dc.getA1().getListOfAccounts().get(i).getAccountID();

                }
            });

        }else if (Dashboard.dc.getA3().getAccessCardNumber().equals(cardNo)){
            for(Accounts a:Dashboard.dc.getA3().getListOfAccounts()){
                listoAcc.add("Account No: "+a.getAccountID());
            }
            adapterOfAccount = new ArrayAdapter(this, android.R.layout.simple_list_item_1,listoAcc);
            listOfAccounts.setAdapter(adapterOfAccount);
            listOfAccounts.setOnItemClickListener(new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                    for( int j =0;j<listOfAccounts.getChildCount();j++){
                        listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                    }
                    listOfAccounts.getChildAt(i).setBackgroundColor(getResources().getColor(android.R.color.holo_green_dark));
                    accountHolders = Dashboard.dc.getA3();
                    accountNo = Dashboard.dc.getA1().getListOfAccounts().get(i).getAccountID();

                }
            });
        }
        PButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if(accountHolders.getAccessCardNumber().equals(cardNo)){
                    if(accountNo.equals("1")){
                        from = Dashboard.dc.getA1().getListOfAccounts().get(0).getBalance();
                        Dashboard.dc.getA1().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amount.getText().toString()));
                    }else if(accountNo.equals("2")){
                        from = Dashboard.dc.getA1().getListOfAccounts().get(1).getBalance();
                        Dashboard.dc.getA1().getListOfAccounts().get(1).setBalance(from-Double.valueOf(amount.getText().toString()));

                    }else if(accountNo.equals("3")){
                        from = Dashboard.dc.getA1().getListOfAccounts().get(2).getBalance();
                        Dashboard.dc.getA1().getListOfAccounts().get(2).setBalance(from-Double.valueOf(amount.getText().toString()));
                    }
                }else if(accountHolders.getAccessCardNumber().equals(cardNo)){
                    if(accountNo.equals("4")){
                        from = Dashboard.dc.getA2().getListOfAccounts().get(0).getBalance();
                        Dashboard.dc.getA2().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amount.getText().toString()));
                    }else if(accountNo.equals("5")){
                        from = Dashboard.dc.getA2().getListOfAccounts().get(1).getBalance();
                        Dashboard.dc.getA2().getListOfAccounts().get(1).setBalance(from-Double.valueOf(amount.getText().toString()));
                    }
                }else if(accountHolders.getAccessCardNumber().equals(cardNo)){
                    if(accountNo.equals("6")){
                        from = Dashboard.dc.getA1().getListOfAccounts().get(0).getBalance();
                        Dashboard.dc.getA1().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amount.getText().toString()));
                    }
                }
                for( int j =0;j<listOfUtilityBills.getChildCount();j++){
                    listOfUtilityBills.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                }
                for( int j =0;j<listOfAccounts.getChildCount();j++){
                    listOfAccounts.getChildAt(j).setBackgroundColor(getResources().getColor(android.R.color.holo_blue_light));
                }

            }

        });


    }
}
