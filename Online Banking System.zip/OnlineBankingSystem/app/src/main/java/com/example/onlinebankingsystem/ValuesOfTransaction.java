package com.example.onlinebankingsystem;

public enum ValuesOfTransaction {

            Utilitiy_Bill_Hydro,
            Utilitiy_Bill_Water,
            Utilitiy_Bill_Gas,
            Utilitiy_Bill_Phone,
            Send_Money_to_Own_Account,
            Send_Money_to_Other_Account;
}
