package com.example.onlinebankingsystem;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class SendMoney extends AppCompatActivity {
    EditText toAcc;
    EditText fromAcc;
    EditText amountToSend;
    Button  sendButton;
    double from,to;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_send_money);
        toAcc = (EditText)findViewById(R.id.toAcc);
        fromAcc = (EditText)findViewById(R.id.fromAcc);
        amountToSend = (EditText)findViewById(R.id.amountToSend);
        sendButton = (Button)findViewById(R.id.sendButton);

        sendButton.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                if (fromAcc.getText().equals("1111")){
                    from = Dashboard.dc.getA1().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA1().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));

                }else if(fromAcc.getText().equals("2222")){
                    from = Dashboard.dc.getA2().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA2().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));

                }else if(fromAcc.getText().equals("3333")){
                    from = Dashboard.dc.getA3().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA3().getListOfAccounts().get(0).setBalance(from-Double.valueOf(amountToSend.getText().toString()));

                }

                if (toAcc.getText().equals("1111")){
                    to = Dashboard.dc.getA1().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA1().getListOfAccounts().get(0).setBalance(from+to);


                }else if(toAcc.getText().equals("2222")){
                    to = Dashboard.dc.getA2().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA2().getListOfAccounts().get(0).setBalance(from+to);


                }else if(toAcc.getText().equals("3333")){
                    to = Dashboard.dc.getA3().getListOfAccounts().get(0).getBalance();
                    Dashboard.dc.getA3().getListOfAccounts().get(0).setBalance(from+to);

                }
            }
        });

    }
}
